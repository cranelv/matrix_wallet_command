module.exports = class ResultCheck{
    constructor(result){
        
    }
}
